import { NextResponse } from "next/server";
import { getProducts } from "@/lib/services/products";
import { adminAuthErrorResponse } from "@/lib/auth-guard";

export async function GET(request: Request) {
  const authError = await adminAuthErrorResponse();
  if (authError) return authError;

  try {
    const url = new URL(request.url);

    const category = url.searchParams.get("category") || undefined;

    const products = await getProducts({
      category,
      // Uncomment this if you later add subCategory support
      // subCategory,
      limit: 100,
    });

    const sample = products.slice(0, 5).map((p) => ({
      id: p.id,
      title: p.title,
    }));

    return NextResponse.json(
      {
        count: products.length,
        sample,
      },
      { status: 200 },
    );
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
