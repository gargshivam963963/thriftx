"use client";

import { AnimatePresence, motion } from "framer-motion";
import {
    ChevronDown,
    ChevronRight,
    CreditCard,
    ShieldCheck,
    LockKeyhole,
    BadgeCheck,
    CheckCircle2,
    Lock,
    IndianRupee,
    Wallet,
    Banknote,
    Sparkles,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import type { PaymentMethod } from "@/lib/types/order";

interface PaymentSectionProps {
    open: boolean;
    onOpen: () => void;
    onPay: (method: PaymentMethod) => void;
    paymentLoading: boolean;
    canPay: boolean;
    disabled?: boolean;
    selectedMethod: PaymentMethod | null;
}

function TrustBadge({
    icon,
    title,
    subtitle,
}: {
    icon: React.ReactNode;
    title: string;
    subtitle: string;
}) {
    return (
        <motion.div
            whileHover={{ y: -2 }}
            className="rounded-xl border border-border bg-card p-3 transition hover:border-border hover:shadow-sm sm:rounded-2xl sm:p-4"
        >
            <div className="mb-2 inline-flex rounded-lg bg-muted p-2 sm:rounded-xl sm:p-2.5">
                {icon}
            </div>
            <h4 className="text-xs font-semibold text-foreground sm:text-sm">
                {title}
            </h4>
            <p className="mt-0.5 text-[11px] text-muted-foreground sm:text-xs">
                {subtitle}
            </p>
        </motion.div>
    );
}

// ─── Consistent icon wrapper ───────────────────────────────────────────────────

function IconBox({ children, selected }: { children: React.ReactNode; selected: boolean }) {
    return (
        <div
            className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl transition-colors sm:h-14 sm:w-14 sm:rounded-2xl ${selected ? "bg-card/10" : "bg-muted"
                }`}
        >
            {children}
        </div>
    );
}

interface PaymentOptionProps {
    icon: React.ReactNode;
    title: string;
    description: string;
    badge: string;
    badgeColor: string;
    features: string[];
    selected: boolean;
    onClick: () => void;
    loading: boolean;
    canPay: boolean;
}

function PaymentOption({
    icon,
    title,
    description,
    badge,
    badgeColor,
    features,
    selected,
    onClick,
    loading,
    canPay,
}: PaymentOptionProps) {
    return (
        <motion.div
            layout
            whileHover={selected ? undefined : { y: -2, scale: 1.005 }}
            whileTap={{ scale: 0.99 }}
            onClick={canPay ? onClick : undefined}
            className={`w-full overflow-hidden rounded-2xl border text-left transition-all sm:rounded-3xl ${selected
                ? "border-foreground bg-foreground text-white shadow-xl"
                : "border-border bg-card hover:border-foreground hover:shadow-md"
                } ${!canPay ? "opacity-50" : "cursor-pointer"}`}
        >
            <div className="flex items-start justify-between p-4 sm:p-6">
                <div className="flex gap-3 sm:gap-4">
                    <IconBox selected={selected}>{icon}</IconBox>

                    <div>
                        <div className="flex items-center gap-2.5 flex-wrap">
                            <h3 className="text-sm font-semibold sm:text-lg">
                                {title}
                            </h3>
                            <span
                                className={`inline-flex rounded-full px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider ${selected
                                    ? "bg-card/20 text-white"
                                    : badgeColor
                                    }`}
                            >
                                {badge}
                            </span>
                        </div>

                        <p
                            className={`mt-1.5 text-xs leading-5 sm:mt-2 sm:text-sm sm:leading-6 ${selected ? "text-muted-foreground" : "text-muted-foreground"
                                }`}
                        >
                            {description}
                        </p>

                        {/* Features */}
                        <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 sm:mt-3">
                            {features.map((feature, i) => (
                                <span
                                    key={i}
                                    className={`inline-flex items-center gap-1 text-[11px] sm:text-xs ${selected ? "text-muted-foreground" : "text-muted-foreground"
                                        }`}
                                >
                                    <CheckCircle2
                                        size={11}
                                        className={
                                            selected
                                                ? "text-emerald-400"
                                                : "text-emerald-500"
                                        }
                                    />
                                    {feature}
                                </span>
                            ))}
                        </div>
                    </div>
                </div>

                {selected && (
                    <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{
                            type: "spring",
                            stiffness: 300,
                            damping: 15,
                        }}
                    >
                        <CheckCircle2
                            className="shrink-0 text-emerald-400"
                            size={22}
                        />
                    </motion.div>
                )}
            </div>

            {/* Inline Payment Button */}
            {selected && (
                <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    className="border-t border-white/10 bg-card/[0.03] px-4 py-4 sm:px-6 sm:py-5"
                >
                    <Button
                        type="button"
                        onClick={onClick}
                        loading={loading}
                        disabled={!canPay}
                        fullWidth
                        size="lg"
                        leftIcon={
                            title.includes("COD") ? (
                                <Banknote className="h-4 w-4" />
                            ) : (
                                <Lock className="h-4 w-4" />
                            )
                        }
                        className="rounded-xl bg-card text-foreground shadow-lg hover:bg-muted sm:rounded-2xl"
                    >
                        {title.includes("COD")
                            ? "Place Order (Pay on Delivery)"
                            : "Continue to Payment"}
                    </Button>
                </motion.div>
            )}
        </motion.div>
    );
}

export default function PaymentSection({
    open,
    onOpen,
    onPay,
    paymentLoading,
    canPay,
    disabled = false,
    selectedMethod,
}: PaymentSectionProps) {
    return (
        <motion.section
            layout
            transition={{ duration: 0.35, ease: "easeOut" }}
            className={`overflow-hidden rounded-2xl border bg-card shadow-sm sm:rounded-3xl ${disabled ? "border-border opacity-60" : "border-border"
                }`}
        >
            <Button
                type="button"
                onClick={disabled ? undefined : onOpen}
                disabled={disabled}
                className="flex w-full items-center justify-between px-4 py-4 sm:px-6 sm:py-5 disabled:cursor-not-allowed"
            >
                <div className="flex items-center gap-3 sm:gap-4">
                    <div
                        className={`flex h-10 w-10 items-center justify-center rounded-xl transition-all duration-300 sm:h-12 sm:w-12 sm:rounded-2xl ${open
                            ? "bg-foreground text-white shadow-lg shadow-foreground/20"
                            : "bg-muted text-muted-foreground"
                            }`}
                    >
                        <CreditCard size={18} className="sm:h-[20px] sm:w-[20px]" />
                    </div>
                    <div className="text-left">
                        <div className="flex items-center gap-2">
                            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-foreground text-[10px] font-bold text-white sm:h-6 sm:w-6 sm:text-xs">
                                3
                            </span>
                            <h2 className="text-sm font-semibold text-foreground sm:text-base sm:text-lg">
                                Payment
                            </h2>
                        </div>
                        <p className="mt-0.5 text-xs text-muted-foreground sm:text-sm">
                            {disabled
                                ? "Select shipping first"
                                : selectedMethod === "cod"
                                    ? "Pay with cash on delivery"
                                    : "Secure checkout with Razorpay"}
                        </p>
                    </div>
                </div>

                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted">
                    {open ? (
                        <ChevronDown size={18} className="text-muted-foreground" />
                    ) : (
                        <ChevronRight size={18} className="text-muted-foreground" />
                    )}
                </div>
            </Button>

            <AnimatePresence initial={false}>
                {open && !disabled && (
                    <motion.div
                        layout
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.3, ease: "easeInOut" }}
                        className="overflow-hidden border-t border-border"
                    >
                        <div className="space-y-4 p-4 sm:p-6">
                            {/* COD */}
                            <PaymentOption
                                icon={<Banknote size={22} />}
                                title="Cash on Delivery"
                                description="Pay when your order arrives at your doorstep. No online payment needed."
                                badge="Pay Later"
                                badgeColor="bg-amber-100 text-amber-700"
                                features={[
                                    "No advance payment",
                                    "Pay in cash at delivery",
                                    "Inspect before you pay",
                                ]}
                                selected={selectedMethod === "cod"}
                                onClick={() => onPay("cod")}
                                loading={paymentLoading && selectedMethod === "cod"}
                                canPay={canPay}
                            />

                            {/* Razorpay */}
                            <PaymentOption
                                icon={<Wallet size={22} />}
                                title="Pay Online (Razorpay)"
                                description="Fast & secure payment via UPI, Cards, Net Banking & Wallets."
                                badge="Instant"
                                badgeColor="bg-blue-100 text-blue-700"
                                features={[
                                    "UPI • GPay • PhonePe",
                                    "Credit & Debit Cards",
                                    "Net Banking • Wallets",
                                ]}
                                selected={selectedMethod === "razorpay"}
                                onClick={() => onPay("razorpay")}
                                loading={
                                    paymentLoading && selectedMethod === "razorpay"
                                }
                                canPay={canPay}
                            />

                            {/* Trust Badges */}
                            <motion.div
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: 0.15 }}
                                className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 sm:gap-3"
                            >
                                <TrustBadge
                                    icon={<ShieldCheck size={15} />}
                                    title="100% Secure"
                                    subtitle="Encrypted checkout"
                                />
                                <TrustBadge
                                    icon={<LockKeyhole size={15} />}
                                    title="Razorpay"
                                    subtitle="Trusted gateway"
                                />
                                <TrustBadge
                                    icon={<BadgeCheck size={15} />}
                                    title="Buyer Protection"
                                    subtitle="Covered purchase"
                                />
                            </motion.div>

                            {/* Security Note */}
                            <motion.div
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                transition={{ delay: 0.2 }}
                                className="flex items-center gap-2.5 rounded-xl bg-subtle px-4 py-3 text-xs text-muted-foreground sm:rounded-2xl sm:text-sm"
                            >
                                <Lock size={14} className="shrink-0 text-muted-foreground" />
                                <span>
                                    Your payment info is encrypted and processed securely by
                                    Razorpay. We never store card details.
                                </span>
                            </motion.div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>

            {!open && !disabled && (
                <div className="border-t border-border px-4 py-4 sm:px-6 sm:py-5">
                    <div className="flex items-center justify-between gap-4">
                        <div className="flex items-start gap-3">
                            <div className="mt-0.5 rounded-full bg-emerald-100 p-1.5 text-emerald-600 sm:p-2">
                                <CheckCircle2
                                    size={16}
                                    className="sm:h-[18px] sm:w-[18px]"
                                />
                            </div>
                            <div>
                                <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-emerald-600 sm:text-[11px]">
                                    Payment Method
                                </p>
                                <h4 className="mt-0.5 text-sm font-semibold text-foreground sm:text-base">
                                    {selectedMethod === "cod"
                                        ? "Cash on Delivery"
                                        : "Online Payment (Razorpay)"}
                                </h4>
                                <p className="text-xs text-muted-foreground sm:text-sm">
                                    {selectedMethod === "cod"
                                        ? "Pay cash at your doorstep"
                                        : "UPI • Cards • Net Banking • Wallets"}
                                </p>
                            </div>
                        </div>

                        <motion.button
                            type="button"
                            onClick={onOpen}
                            whileHover={{ scale: 1.03 }}
                            whileTap={{ scale: 0.97 }}
                            className="shrink-0 rounded-xl border border-border px-3 py-1.5 text-xs font-medium transition hover:border-foreground hover:bg-foreground hover:text-white sm:px-4 sm:py-2 sm:text-sm"
                        >
                            Change
                        </motion.button>
                    </div>
                </div>
            )}
        </motion.section>
    );
}

