import type { Metadata } from "next";
import { Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";
import NextTopLoader from "nextjs-toploader";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { AuthProvider } from "@/lib/AuthContext";
import { WishlistProvider } from "@/lib/WishlistContext";
import { CartProvider } from "@/lib/CartContext";
import { ThemeProvider } from "@/lib/ThemeContext";
import AnalyticsProviderWrapper from "@/components/AnalyticsProviderWrapper";
import BottomNav from "@/components/BottomNav";
import { Toaster } from "sonner";
import { siteConfig } from "@/lib/seo";

// ─── Design System: ONE premium font family ─────────────────────────────────
// Plus Jakarta Sans is the single typeface for the entire THRIFTX design system.
// It powers both display (headings) and body text via distinct weights.
const jakarta = Plus_Jakarta_Sans({
  subsets: ["latin"],
  variable: "--font-sans",
  weight: ["400", "500", "600", "700", "800"],
});

export const metadata: Metadata = {
  metadataBase: new URL(siteConfig.url),

  title: {
    default: siteConfig.title,
    template: "%s | THRIFTX",
  },

  description: siteConfig.description,

  keywords: siteConfig.keywords,

  applicationName: siteConfig.name,

  creator: siteConfig.creator,

  publisher: siteConfig.publisher,

  category: siteConfig.category,

  alternates: {
    canonical: "/",
  },

  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
      "max-video-preview": -1,
      "max-snippet": -1,
    },
  },

  openGraph: {
    type: "website",
    locale: "en_IN",
    url: siteConfig.url,
    siteName: siteConfig.name,
    title: siteConfig.title,
    description: siteConfig.description,
  },

  twitter: {
    card: "summary_large_image",
    title: siteConfig.title,
    description: siteConfig.description,
  },
};

const organizationJsonLd = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: siteConfig.name,
  url: siteConfig.url,
  logo: `${siteConfig.url}/icon.jpg`,
  description: siteConfig.description,
  sameAs: [
    "https://instagram.com/thriftx",
    "https://twitter.com/thriftx",
  ],
};

const websiteJsonLd = {
  "@context": "https://schema.org",
  "@type": "WebSite",
  name: siteConfig.name,
  url: siteConfig.url,
  description: siteConfig.description,
  potentialAction: {
    "@type": "SearchAction",
    target: {
      "@type": "EntryPoint",
      urlTemplate: `${siteConfig.url}/shop?search={search_term_string}`,
    },
    "query-input": "required name=search_term_string",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={jakarta.variable}
      suppressHydrationWarning
    >
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationJsonLd) }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteJsonLd) }}
        />
      </head>
      <body
        className="min-h-screen overflow-x-hidden antialiased flex flex-col"
        style={{ fontFamily: "var(--font-sans), system-ui, -apple-system, sans-serif" }}
        suppressHydrationWarning
      >
        <NextTopLoader
          color="#000000"
          height={3}
          showSpinner={false}
          crawl
          crawlSpeed={200}
          speed={300}
          easing="ease"
          shadow={false}
          initialPosition={0.08}
        />

        <ThemeProvider>
          <AuthProvider>
            <WishlistProvider>
              <CartProvider>
                <AnalyticsProviderWrapper>
                  <Header />

                  <main className="flex flex-1 flex-col">
                    {children}
                  </main>

                  <Footer />
                  <BottomNav />

                  <Toaster
                    position="top-right"
                    richColors
                    closeButton
                    duration={3000}
                  />
                </AnalyticsProviderWrapper>
              </CartProvider>
            </WishlistProvider>
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
